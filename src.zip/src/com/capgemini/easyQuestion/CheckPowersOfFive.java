package com.capgemini.easyQuestion;

public class CheckPowersOfFive {
    public static boolean powerOfFive(int input){
        if (input % 5 != 0 || input == 0) {
            return false;
        }

        if (input == 5) {
            return true;
        }

        return powerOfFive(input/5);
    }
    public static void main(String[] args) {
        System.out.println("1000: " + powerOfFive(1000));
        System.out.println("125: " + powerOfFive(125));
        System.out.println("5: " + powerOfFive(5));
        System.out.println("0: " + powerOfFive(0));
        System.out.println("10: " + powerOfFive(10));
        System.out.println("25: " + powerOfFive(25));
    }
}
