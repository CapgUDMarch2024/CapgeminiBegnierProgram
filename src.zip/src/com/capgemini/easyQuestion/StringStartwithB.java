package com.capgemini.easyQuestion;

public class StringStartwithB {
    public static void main(String[] args) {
        String[] names = {"Abby", "Ben", "Bill", "Brian", "Craig", "Sassandra",
                "Collin", "David", "Donny", "Mitchell" };

        for (int i =0; i< names.length; i++)
        {
            if (names[i].charAt(0) == 'B')
            {
                System.out.println(names[i]);
            }
        }
//        Or you can similarly use startsWith() which is Java string method:
//
//        if (names[i].startsWith("B"))
//        {
//            System.out.println(names[i]);
//        }
    }
}
