package com.capgemini.easyQuestion;

public class PangramStringExample2 {
    public static void containAllLetters(String string)
    {
//converts the given string to lowercase
        string = string.toLowerCase();
        boolean allLetterPresent = true;
//loop iterate over each character of the given string
        for (char ch = 'a'; ch <= 'z'; ch++)
        {
//checks if the string does not contains all the letters
            if (!string.contains(String.valueOf(ch)))
            {
                allLetterPresent = false;
                break;
            }
        }
//checks if all the letters are presented or not
        if (allLetterPresent)
            System.out.println("Pangram String");
        else
            System.out.println("Not a Pangram String");
    }
    public static void main(String args[])
    {
        String string = "Abcdefghijklmnopqrstuvwxyz12";
        containAllLetters(string);
    }
}
