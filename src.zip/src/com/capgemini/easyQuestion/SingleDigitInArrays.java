package com.capgemini.easyQuestion;

public class SingleDigitInArrays {
    public static void main (String[] args) {

        int inputArray[] = {7, 12, 5, 9, 15};

        int count = 0;
        System.out.print ("Single digit array number are: ");

        //initiate the loop to find the single digits
        for (int i = 0; i < inputArray.length; i++)  {

            //take a for loop to check every values
            if (inputArray[i] >= 0 && inputArray[i] <= 9){

                System.out.print(inputArray [i] + " ");

                //increment the count value if any single digit found
                count+=1;
            }
        }

        //if no single digit detected
        if(count==0){
            System.out.print(" N/A ");
        }
    }
}
